package com.poolvision.live

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import androidx.core.app.NotificationCompat

/**
 * Foreground service that captures the screen ONLY after the user
 * approves the system MediaProjection dialog in MainActivity.
 * It never touches the game, never injects input, and stops fully
 * when the user presses Stop.
 */
class ScreenCaptureService : Service() {

    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var thread: HandlerThread? = null
    private var handler: Handler? = null
    private var lastRunMs = 0L
    private var intervalMs = 500L
    private var captureWidth = 720

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopCapture()
            stopSelf()
            return START_NOT_STICKY
        }
        val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, 0) ?: 0
        val data: Intent? = if (Build.VERSION.SDK_INT >= 33) {
            intent?.getParcelableExtra(EXTRA_DATA, Intent::class.java)
        } else {
            @Suppress("DEPRECATION") intent?.getParcelableExtra(EXTRA_DATA)
        }
        intervalMs = (intent?.getLongExtra(EXTRA_INTERVAL, 500L) ?: 500L).coerceIn(150L, 3000L)
        captureWidth = intent?.getIntExtra(EXTRA_WIDTH, 720) ?: 720
        if (data == null) { stopSelf(); return START_NOT_STICKY }

        startForegroundWithNotification()
        startCapture(resultCode, data)
        return START_STICKY
    }

    private fun startForegroundWithNotification() {
        val channelId = "pool_vision_live"
        val manager = getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(
            NotificationChannel(channelId, "Pool Vision Live", NotificationManager.IMPORTANCE_LOW)
        )
        val notification: Notification = NotificationCompat.Builder(this, channelId)
            .setContentTitle("Pool Vision Live يعمل")
            .setContentText("جارٍ تحليل الشاشة تعليميًا — اضغط إيقاف من التطبيق للإنهاء")
            .setSmallIcon(android.R.drawable.presence_video_online)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(1, notification)
        }
    }

    private fun startCapture(resultCode: Int, data: Intent) {
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = mpm.getMediaProjection(resultCode, data)
        val metrics = resources.displayMetrics
        val screenW = metrics.widthPixels
        val screenH = metrics.heightPixels
        val scale = captureWidth.toFloat() / screenW
        val w = captureWidth
        val h = (screenH * scale).toInt().coerceAtLeast(2)
        val density = metrics.densityDpi

        thread = HandlerThread("pool-vision-capture").also { it.start() }
        handler = Handler(thread!!.looper)
        reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        projection?.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { stopCapture() }
        }, handler)

        reader?.setOnImageAvailableListener({ r ->
            val now = System.currentTimeMillis()
            if (now - lastRunMs < intervalMs) {
                // Drop the frame: throttling is what saves battery.
                r.acquireLatestImage()?.close()
                return@setOnImageAvailableListener
            }
            lastRunMs = now
            val image = r.acquireLatestImage() ?: return@setOnImageAvailableListener
            try {
                val plane = image.planes[0]
                val buffer = plane.buffer
                val pixelStride = plane.pixelStride
                val rowStride = plane.rowStride
                val rowPadding = rowStride - pixelStride * w
                val padded = Bitmap.createBitmap(w + rowPadding / pixelStride, h, Bitmap.Config.ARGB_8888)
                padded.copyPixelsFromBuffer(buffer)
                val bitmap = Bitmap.createBitmap(padded, 0, 0, w, h)
                if (padded !== bitmap) padded.recycle()
                val output = BallDetector.detect(bitmap)
                AnalysisBus.listener?.invoke(
                    AnalysisResult(
                        output.balls, w, h,
                        System.currentTimeMillis(), output.table
                    )
                )
                bitmap.recycle()
            } catch (_: Exception) {
                // A single bad frame must never crash the service.
            } finally {
                image.close()
            }
        }, handler)

        virtualDisplay = projection?.createVirtualDisplay(
            "PoolVisionLive", w, h, density,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader?.surface, null, handler
        )
        AnalysisBus.running = true
    }

    private fun stopCapture() {
        AnalysisBus.running = false
        try { virtualDisplay?.release() } catch (_: Exception) {}
        try { reader?.close() } catch (_: Exception) {}
        try { projection?.stop() } catch (_: Exception) {}
        virtualDisplay = null; reader = null; projection = null
        thread?.quitSafely(); thread = null
    }

    override fun onDestroy() {
        stopCapture()
        super.onDestroy()
    }

    companion object {
        const val ACTION_STOP = "com.poolvision.live.STOP"
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_DATA = "data"
        const val EXTRA_INTERVAL = "interval_ms"
        const val EXTRA_WIDTH = "width_px"
    }
}
