package com.poolvision.live

import android.graphics.Bitmap
import android.graphics.Color
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.sqrt

/**
 * Approximate ball detection, v1.2 — TABLE FIRST.
 *
 * Why the old version failed (seen on a real device): it averaged the
 * colours of the WHOLE screen to guess the felt colour, then reported
 * balls in full-screen coordinates. The screen also contains the game's
 * dark surround, avatars, buttons and the row of small round ball-icons
 * in the game's top bar — those icons were detected as "balls in a
 * line", the real balls (tiny inside the table area) were lost or
 * squeezed, taps missed, and the pockets (drawn for the full view)
 * did not match anything.
 *
 * New approach:
 *  1. Find the table: the playing surface is the largest, most
 *     rectangular, single-colour region in the frame. Candidate felt
 *     colours come from a colour histogram; each candidate's largest
 *     connected region is scored by area x rectangular fill.
 *  2. Detect balls ONLY inside that rectangle, with size limits tied
 *     to the table size (a real ball is about 1/40 of the table
 *     length), and report positions RELATIVE to the table, so the
 *     drawing, the pockets and the taps all share one coordinate
 *     system that fills the view properly.
 * Still approximate and for learning — not a measurement tool.
 */
object BallDetector {

    /** Balls (table-relative) plus the table found, or null table. */
    data class Output(val balls: List<DetectedBall>, val table: TableRect?)

    fun detect(source: Bitmap): Output {
        // Work on a downscaled copy: faster and less noisy.
        val scale = if (source.width > 480) 480f / source.width else 1f
        val bmp = if (scale < 1f) {
            Bitmap.createScaledBitmap(
                source,
                (source.width * scale).toInt().coerceAtLeast(40),
                (source.height * scale).toInt().coerceAtLeast(40),
                true
            )
        } else source
        try {
            return detectOnBitmap(bmp)
        } finally {
            if (bmp !== source) bmp.recycle()
        }
    }

    private fun detectOnBitmap(bmp: Bitmap): Output {
        val w = bmp.width
        val h = bmp.height
        if (w < 60 || h < 60) return Output(emptyList(), null)
        val pixels = IntArray(w * h)
        bmp.getPixels(pixels, 0, w, 0, 0, w, h)

        val cell = 3
        val cols = w / cell
        val rows = h / cell
        if (cols < 20 || rows < 20) return Output(emptyList(), null)

        // Quantised colour bucket per grid cell (sampled at cell centre).
        val bucket = IntArray(cols * rows)
        val counts = HashMap<Int, Int>()
        for (gy in 0 until rows) {
            for (gx in 0 until cols) {
                val c = pixels[(gy * cell + cell / 2) * w + (gx * cell + cell / 2)]
                val key = ((Color.red(c) / 32) shl 6) or
                    ((Color.green(c) / 32) shl 3) or (Color.blue(c) / 32)
                bucket[gy * cols + gx] = key
                counts[key] = (counts[key] ?: 0) + 1
            }
        }
        val totalCells = cols * rows
        val candidates = counts.entries
            .filter { it.value >= totalCells * 0.04 }
            .sortedByDescending { it.value }
            .take(6)
        if (candidates.isEmpty()) return Output(emptyList(), null)

        // ---- Step 1: find the table rectangle ----
        var bestRect: IntArray? = null // minGx, minGy, maxGx, maxGy
        var bestFelt = 0
        var bestScore = 0.0
        val seen = BooleanArray(totalCells)
        val stack = ArrayDeque<Int>()
        val cluster = ArrayList<Int>()
        for ((key, _) in candidates) {
            // Largest connected component of this colour.
            seen.fill(false)
            var compRect: IntArray? = null
            var compSize = 0
            for (i in 0 until totalCells) {
                if (bucket[i] != key || seen[i]) continue
                cluster.clear()
                stack.clear(); stack.addLast(i); seen[i] = true
                var mnx = Int.MAX_VALUE; var mxx = Int.MIN_VALUE
                var mny = Int.MAX_VALUE; var mxy = Int.MIN_VALUE
                while (stack.isNotEmpty()) {
                    val cur = stack.removeLast(); cluster.add(cur)
                    val cx = cur % cols; val cy = cur / cols
                    if (cx < mnx) mnx = cx; if (cx > mxx) mxx = cx
                    if (cy < mny) mny = cy; if (cy > mxy) mxy = cy
                    if (cx > 0 && bucket[cur - 1] == key && !seen[cur - 1]) { seen[cur - 1] = true; stack.addLast(cur - 1) }
                    if (cx < cols - 1 && bucket[cur + 1] == key && !seen[cur + 1]) { seen[cur + 1] = true; stack.addLast(cur + 1) }
                    if (cy > 0 && bucket[cur - cols] == key && !seen[cur - cols]) { seen[cur - cols] = true; stack.addLast(cur - cols) }
                    if (cy < rows - 1 && bucket[cur + cols] == key && !seen[cur + cols]) { seen[cur + cols] = true; stack.addLast(cur + cols) }
                }
                if (cluster.size > compSize) {
                    compSize = cluster.size
                    compRect = intArrayOf(mnx, mny, mxx, mxy)
                }
            }
            val rect = compRect ?: continue
            val bw = rect[2] - rect[0] + 1
            val bh = rect[3] - rect[1] + 1
            if (bw < 10 || bh < 6) continue
            val fill = compSize.toDouble() / (bw * bh)
            val areaFrac = compSize.toDouble() / totalCells
            // The playing surface is a big, almost solid rectangle.
            if (fill < 0.78 || areaFrac < 0.10 || areaFrac > 0.88) continue
            val score = areaFrac * fill
            if (score > bestScore) {
                bestScore = score; bestRect = rect; bestFelt = key
            }
        }
        val rect = bestRect ?: return Output(emptyList(), null)

        // Felt colour = average of the winning colour's cell centres.
        var fr = 0L; var fg = 0L; var fb = 0L; var fn = 0
        for (i in 0 until totalCells) {
            if (bucket[i] != bestFelt) continue
            val c = pixels[(i / cols * cell + cell / 2) * w + (i % cols * cell + cell / 2)]
            fr += Color.red(c); fg += Color.green(c); fb += Color.blue(c); fn++
        }
        if (fn == 0) return Output(emptyList(), null)
        val feltR = (fr / fn).toInt(); val feltG = (fg / fn).toInt(); val feltB = (fb / fn).toInt()

        val tableLeftPx = rect[0] * cell
        val tableTopPx = rect[1] * cell
        val tableWPx = (rect[2] - rect[0] + 1) * cell
        val tableHPx = (rect[3] - rect[1] + 1) * cell
        val table = TableRect(
            left = tableLeftPx.toFloat() / w,
            top = tableTopPx.toFloat() / h,
            right = (tableLeftPx + tableWPx).toFloat() / w,
            bottom = (tableTopPx + tableHPx).toFloat() / h,
            aspect = tableWPx.toFloat() / tableHPx
        )

        // ---- Step 2: balls INSIDE the table only ----
        // Grid restricted to the table rectangle (1-cell inset for rails).
        val gCols = tableWPx / cell
        val gRows = tableHPx / cell
        if (gCols < 20 || gRows < 10) return Output(emptyList(), table)
        val filled = BooleanArray(gCols * gRows)
        for (gy in 0 until gRows) {
            for (gx in 0 until gCols) {
                var diff = 0; var n = 0
                val x0 = tableLeftPx + gx * cell
                val y0 = tableTopPx + gy * cell
                for (y in y0 until minOf(y0 + cell, tableTopPx + tableHPx, h)) {
                    for (x in x0 until minOf(x0 + cell, tableLeftPx + tableWPx, w)) {
                        val c = pixels[y * w + x]
                        val d = abs(Color.red(c) - feltR) +
                            abs(Color.green(c) - feltG) +
                            abs(Color.blue(c) - feltB)
                        if (d > 100) diff++
                        n++
                    }
                }
                filled[gy * gCols + gx] = n > 0 && diff * 5 >= n * 2 // >=40% differs
            }
        }

        val seen2 = BooleanArray(filled.size)
        val stack2 = ArrayDeque<Int>()
        val raw = ArrayList<DetectedBall>()
        val diameters = ArrayList<Float>()
        for (i in filled.indices) {
            if (!filled[i] || seen2[i]) continue
            val cells = ArrayList<Int>()
            stack2.clear(); stack2.addLast(i); seen2[i] = true
            var mnx = Int.MAX_VALUE; var mxx = Int.MIN_VALUE
            var mny = Int.MAX_VALUE; var mxy = Int.MIN_VALUE
            while (stack2.isNotEmpty()) {
                val cur = stack2.removeLast(); cells.add(cur)
                val cx = cur % gCols; val cy = cur / gCols
                if (cx < mnx) mnx = cx; if (cx > mxx) mxx = cx
                if (cy < mny) mny = cy; if (cy > mxy) mxy = cy
                if (cx > 0 && filled[cur - 1] && !seen2[cur - 1]) { seen2[cur - 1] = true; stack2.addLast(cur - 1) }
                if (cx < gCols - 1 && filled[cur + 1] && !seen2[cur + 1]) { seen2[cur + 1] = true; stack2.addLast(cur + 1) }
                if (cy > 0 && filled[cur - gCols] && !seen2[cur - gCols]) { seen2[cur - gCols] = true; stack2.addLast(cur - gCols) }
                if (cy < gRows - 1 && filled[cur + gCols] && !seen2[cur + gCols]) { seen2[cur + gCols] = true; stack2.addLast(cur + gCols) }
            }
            val bwPx = (mxx - mnx + 1) * cell
            val bhPx = (mxy - mny + 1) * cell
            // A ball is ~1/40 of the table length: reject anything far
            // from that size — this kills UI icons, shadows and rails.
            if (bwPx < tableWPx * 0.013 || bwPx > tableWPx * 0.062) continue
            if (bhPx < tableHPx * 0.020 || bhPx > tableHPx * 0.115) continue
            val pxRatio = bwPx.toFloat() / bhPx
            if (pxRatio < 0.55f || pxRatio > 1.8f) continue
            val boxCells = (mxx - mnx + 1) * (mxy - mny + 1)
            if (boxCells == 0 || cells.size.toFloat() / boxCells < 0.48f) continue

            // Centre + colour from the inner part of the cluster only,
            // so felt pixels at the rim do not wash the colour out.
            var sx = 0.0; var sy = 0.0; var sn = 0
            var sr = 0L; var sg = 0L; var sb = 0L
            val cxF = (mnx + mxx) / 2f; val cyF = (mny + mxy) / 2f
            for (idx in cells) {
                val gx = idx % gCols; val gy = idx / gCols
                if (abs(gx - cxF) > (mxx - mnx + 1) * 0.32f) continue
                if (abs(gy - cyF) > (mxy - mny + 1) * 0.32f) continue
                val px = tableLeftPx + gx * cell + cell / 2
                val py = tableTopPx + gy * cell + cell / 2
                if (px >= w || py >= h) continue
                val c = pixels[py * w + px]
                sx += px; sy += py; sn++
                sr += Color.red(c); sg += Color.green(c); sb += Color.blue(c)
            }
            if (sn == 0) continue
            val ar = (sr / sn).toInt(); val ag = (sg / sn).toInt(); val ab = (sb / sn).toInt()
            val brightness = (ar + ag + ab) / 3
            val spread = maxOf(ar, ag, ab) - minOf(ar, ag, ab)
            val isWhite = brightness > 175 && spread < 60
            val centerX = ((sx / sn) - tableLeftPx).toFloat() / tableWPx
            val centerY = ((sy / sn) - tableTopPx).toFloat() / tableHPx
            if (centerX !in 0f..1f || centerY !in 0f..1f) continue
            val diameter = sqrt((bwPx * bhPx).toDouble()).toFloat()
            diameters.add(diameter)
            raw.add(
                DetectedBall(
                    centerX, centerY,
                    diameter / 2f / tableWPx,
                    isWhite, ar, ag, ab
                )
            )
        }
        if (raw.isEmpty()) return Output(emptyList(), table)

        // Keep sizes close to the median ball size, drop duplicates
        // whose centres are closer than ~0.8 of a ball diameter, and
        // cap at the 16 balls a real table can have.
        val sortedD = diameters.sorted()
        val median = sortedD[sortedD.size / 2]
        val kept = ArrayList<DetectedBall>()
        for (ball in raw.sortedByDescending { it.radius }) {
            val d = ball.radius * 2 * tableWPx
            if (median > 0 && (d < median * 0.55f || d > median * 1.9f)) continue
            var dup = false
            for (other in kept) {
                val distPx = hypot(
                    (ball.centerX - other.centerX) * tableWPx,
                    (ball.centerY - other.centerY) * tableHPx
                )
                if (distPx < median * 0.8f) { dup = true; break }
            }
            if (!dup) kept.add(ball)
            if (kept.size >= 16) break
        }
        return Output(kept, table)
    }
}
