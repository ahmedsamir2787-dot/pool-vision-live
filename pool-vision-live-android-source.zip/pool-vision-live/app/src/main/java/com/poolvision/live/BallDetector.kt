package com.poolvision.live

import android.graphics.Bitmap
import android.graphics.Color
import kotlin.math.sqrt

/**
 * Approximate ball detection without external libraries.
 *
 * Idea: pool felt is the dominant, fairly uniform background colour.
 * Pixels that differ strongly from the felt colour are grouped into
 * grid cells; neighbouring filled cells form a cluster. Each cluster
 * whose size and shape are roughly circular is reported as a ball.
 * A ball is classified as the white (cue) ball when its average colour
 * is bright and low-saturation. This is approximate, for learning.
 */
object BallDetector {

    fun detect(source: Bitmap, cell: Int = 6): List<DetectedBall> {
        val w = source.width
        val h = source.height
        if (w < 40 || h < 40) return emptyList()

        val pixels = IntArray(w * h)
        source.getPixels(pixels, 0, w, 0, 0, w, h)

        // Estimate felt colour from the image corners / centre average.
        var fr = 0L; var fg = 0L; var fb = 0L; var fn = 0
        for (y in 0 until h step 16) for (x in 0 until w step 16) {
            val c = pixels[y * w + x]
            fr += Color.red(c); fg += Color.green(c); fb += Color.blue(c); fn++
        }
        if (fn == 0) return emptyList()
        val feltR = (fr / fn).toInt(); val feltG = (fg / fn).toInt(); val feltB = (fb / fn).toInt()

        val cols = w / cell; val rows = h / cell
        val filled = BooleanArray(cols * rows)
        for (gy in 0 until rows) for (gx in 0 until cols) {
            var diff = 0; var n = 0
            for (y in gy * cell until minOf((gy + 1) * cell, h)) {
                for (x in gx * cell until minOf((gx + 1) * cell, w)) {
                    val c = pixels[y * w + x]
                    val d = kotlin.math.abs(Color.red(c) - feltR) +
                        kotlin.math.abs(Color.green(c) - feltG) +
                        kotlin.math.abs(Color.blue(c) - feltB)
                    if (d > 110) diff++
                    n++
                }
            }
            filled[gy * cols + gx] = n > 0 && diff * 2 > n // >50% differs
        }

        // Connected components over filled cells (4-neighbour flood fill).
        val seen = BooleanArray(filled.size)
        val balls = mutableListOf<DetectedBall>()
        val stack = ArrayDeque<Int>()
        for (i in filled.indices) {
            if (!filled[i] || seen[i]) continue
            val cluster = mutableListOf<Int>()
            stack.clear(); stack.addLast(i); seen[i] = true
            while (stack.isNotEmpty()) {
                val cur = stack.removeLast(); cluster.add(cur)
                val cx = cur % cols; val cy = cur / cols
                val neighbours = listOf(
                    if (cx > 0) cur - 1 else -1,
                    if (cx < cols - 1) cur + 1 else -1,
                    if (cy > 0) cur - cols else -1,
                    if (cy < rows - 1) cur + cols else -1
                )
                for (nb in neighbours) {
                    if (nb >= 0 && filled[nb] && !seen[nb]) { seen[nb] = true; stack.addLast(nb) }
                }
            }
            // A ball occupies a small, roughly square cluster of cells.
            if (cluster.size !in 2..120) continue
            var minX = Int.MAX_VALUE; var maxX = Int.MIN_VALUE
            var minY = Int.MAX_VALUE; var maxY = Int.MIN_VALUE
            var sr = 0L; var sg = 0L; var sb = 0L; var sn = 0
            for (idx in cluster) {
                val gx = idx % cols; val gy = idx / cols
                minX = minOf(minX, gx); maxX = maxOf(maxX, gx)
                minY = minOf(minY, gy); maxY = maxOf(maxY, gy)
                val px = gx * cell + cell / 2; val py = gy * cell + cell / 2
                if (px < w && py < h) {
                    val c = pixels[py * w + px]
                    sr += Color.red(c); sg += Color.green(c); sb += Color.blue(c); sn++
                }
            }
            val cw = (maxX - minX + 1).toFloat(); val ch = (maxY - minY + 1).toFloat()
            if (cw == 0f || ch == 0f) continue
            val ratio = maxOf(cw, ch) / minOf(cw, ch)
            if (ratio > 1.9f) continue // too elongated to be a ball
            if (sn == 0) continue
            val ar = (sr / sn).toInt(); val ag = (sg / sn).toInt(); val ab = (sb / sn).toInt()
            val brightness = (ar + ag + ab) / 3
            val spread = maxOf(ar, ag, ab) - minOf(ar, ag, ab)
            val isWhite = brightness > 175 && spread < 55
            val centerX = ((minX + maxX + 1) * cell / 2f) / w
            val centerY = ((minY + maxY + 1) * cell / 2f) / h
            val radius = (sqrt((cw * ch).toDouble()) * cell / 2.0).toFloat() / w
            balls.add(DetectedBall(centerX, centerY, radius, isWhite, ar, ag, ab))
        }
        return balls.sortedByDescending { it.radius }.take(22)
    }
}
