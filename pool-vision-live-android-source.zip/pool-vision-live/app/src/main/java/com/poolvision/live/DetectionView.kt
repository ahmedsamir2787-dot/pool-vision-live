package com.poolvision.live

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.view.View

/** Draws the latest detected balls as visible circles over a table outline. */
class DetectionView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private var balls: List<DetectedBall> = emptyList()

    private val tablePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(27, 94, 52); style = Paint.Style.FILL
    }
    private val railPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(101, 67, 33); style = Paint.Style.STROKE; strokeWidth = 14f
    }
    private val ballPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; style = Paint.Style.STROKE; strokeWidth = 3f
    }
    private val whiteRingPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.YELLOW; style = Paint.Style.STROKE; strokeWidth = 5f
    }

    fun submit(result: AnalysisResult) {
        balls = result.balls
        post { invalidate() }
    }

    fun clear() {
        balls = emptyList()
        post { invalidate() }
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), tablePaint)
        canvas.drawRect(7f, 7f, width - 7f, height - 7f, railPaint)
        for (ball in balls) {
            val cx = ball.centerX * width
            val cy = ball.centerY * height
            val r = (ball.radius * width).coerceIn(8f, 60f)
            ballPaint.color = Color.rgb(ball.avgRed, ball.avgGreen, ball.avgBlue)
            canvas.drawCircle(cx, cy, r, ballPaint)
            canvas.drawCircle(cx, cy, r, if (ball.isWhite) whiteRingPaint else ringPaint)
        }
    }
}
