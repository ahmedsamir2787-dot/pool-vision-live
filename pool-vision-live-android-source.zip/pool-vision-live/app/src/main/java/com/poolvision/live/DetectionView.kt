package com.poolvision.live

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.PointF
import android.graphics.RectF
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import kotlin.math.hypot
import kotlin.math.min

/**
 * Draws the detected table, its six pockets and the detected balls,
 * plus the aiming lines once a cue ball and a target ball are picked.
 *
 * v1.2 fixes, after real-device testing of 1.1:
 *  - Everything is drawn in TABLE coordinates inside a letterboxed
 *    table rectangle that keeps the table's real aspect ratio, so
 *    balls spread over the whole table instead of clustering in one
 *    line, and the pockets sit exactly at the table corners/sides.
 *  - Pockets are drawn LARGE (about 3% of the table width, with a
 *    white ring; the chosen one gets a thick yellow ring) — in 1.1
 *    they were 16px dots lost under the rail.
 *  - Taps are measured in pixels with a finger-sized tolerance
 *    (at least ~44dp), and the cue/target picks are stored as
 *    POSITIONS that re-snap to the nearest ball each frame and
 *    survive a few missed frames — in 1.1 a tap only worked within
 *    a tiny normalised radius and the picks vanished whenever the
 *    detector jittered, so "nothing happened" when tapping.
 */
class DetectionView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private val density = resources.displayMetrics.density

    private var balls: List<DetectedBall> = emptyList()
    private var tableFound: Boolean = false
    private var tableAspect: Float = 2.0f

    // Picks are stored as table-relative positions (sticky), with the
    // last snapped ball radius for drawing the ghost ball.
    private var cuePos: PointF? = null
    private var targetPos: PointF? = null
    private var cueRadius: Float = 0.016f
    private var targetRadius: Float = 0.016f
    private var pocketIndex: Int = -1 // -1 = nearest pocket, automatic

    /** The rectangle (view pixels) the table is drawn in; set in onDraw. */
    private val tableRectPx = RectF()
    private var tableRectValid = false

    /** Called whenever the user changes the cue / target / pocket pick. */
    var onSelectionChanged: (() -> Unit)? = null

    // Six pockets in table coordinates: corners + middle of long sides.
    private val pockets = listOf(
        0.012f to 0.02f, 0.5f to 0.012f, 0.988f to 0.02f,
        0.012f to 0.98f, 0.5f to 0.988f, 0.988f to 0.98f
    )
    private val pocketNames = listOf(
        "العلوي الأيسر", "العلوي الأوسط", "العلوي الأيمن",
        "السفلي الأيسر", "السفلي الأوسط", "السفلي الأيمن"
    )

    private val tablePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(27, 94, 52); style = Paint.Style.FILL
    }
    private val railPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(101, 67, 33); style = Paint.Style.STROKE
    }
    private val ballPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; style = Paint.Style.STROKE; strokeWidth = 2.5f * density
    }
    private val cueRingPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.YELLOW; style = Paint.Style.STROKE; strokeWidth = 4f * density
    }
    private val targetRingPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(255, 152, 0); style = Paint.Style.STROKE; strokeWidth = 4f * density
    }
    private val pocketPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.BLACK; style = Paint.Style.FILL
    }
    private val pocketRingPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; style = Paint.Style.STROKE; strokeWidth = 3f * density
    }
    private val chosenPocketPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.YELLOW; style = Paint.Style.STROKE; strokeWidth = 5f * density
    }
    private val aimPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; style = Paint.Style.STROKE; strokeWidth = 5f * density
    }
    private val targetLinePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(76, 175, 80); style = Paint.Style.STROKE; strokeWidth = 5f * density
    }
    private val deflectPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.YELLOW; style = Paint.Style.STROKE; strokeWidth = 4f * density
        pathEffect = DashPathEffect(floatArrayOf(14f * density, 10f * density), 0f)
    }
    private val ghostPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; style = Paint.Style.STROKE; strokeWidth = 3f * density
    }
    private val labelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; textSize = 13f * density
        setShadowLayer(4f, 0f, 2f, Color.BLACK)
    }
    private val hintPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; textSize = 15f * density
        textAlign = Paint.Align.CENTER
        setShadowLayer(4f, 0f, 2f, Color.BLACK)
    }

    fun submit(result: AnalysisResult) {
        balls = result.balls
        tableFound = result.table != null
        result.table?.let { tableAspect = it.aspect.coerceIn(1.2f, 2.6f) }
        // Re-snap the sticky picks to the nearest ball in this frame;
        // if a ball is missed for a frame or two the pick (and its
        // lines) stay where they were instead of disappearing.
        cuePos?.let { pos ->
            nearestBall(pos.x, pos.y, snapTolerance())?.let {
                pos.set(it.centerX, it.centerY); cueRadius = it.radius
            }
        }
        targetPos?.let { pos ->
            nearestBall(pos.x, pos.y, snapTolerance())?.let {
                pos.set(it.centerX, it.centerY); targetRadius = it.radius
            }
        }
        if (cuePos == null) {
            balls.firstOrNull { it.isWhite }?.let {
                cuePos = PointF(it.centerX, it.centerY); cueRadius = it.radius
            }
        }
        post { invalidate() }
    }

    fun clear() {
        balls = emptyList()
        tableFound = false
        cuePos = null
        targetPos = null
        pocketIndex = -1
        post { invalidate() }
    }

    /** One-line Arabic summary of the current pick, for the result text. */
    fun selectionSummary(): String {
        val cue = cuePos
        val target = targetPos
        return when {
            !tableFound ->
                "الخطوط: الطاولة غير ظاهرة في الشاشة — كبّر اللعبة حتى تملأ الطاولة الشاشة."
            cue == null ->
                "الخطوط: اضغط على الكرة البيضاء أولاً، ثم على الكرة الهدف."
            target == null ->
                "البيضاء محددة ✓ — اضغط على الكرة الهدف لعرض الخطوط."
            else -> {
                val pocket = chosenPocket()
                val name = pocket?.let { pocketNames[pockets.indexOf(it)] } ?: "الأقرب"
                "الخطوط ظاهرة ✓ — الجيب: $name — اضغط على جيب آخر لتغييره، أو على مكان فاضي لمسح الهدف."
            }
        }
    }

    /** Distance in "table-height units" so X and Y compare fairly. */
    private fun tableDist(x1: Float, y1: Float, x2: Float, y2: Float): Float =
        hypot((x1 - x2) * tableAspect, y1 - y2)

    private fun snapTolerance(): Float = 0.11f

    private fun nearestBall(x: Float, y: Float, maxDist: Float): DetectedBall? {
        var best: DetectedBall? = null
        var bestDist = maxDist
        for (ball in balls) {
            val d = tableDist(ball.centerX, ball.centerY, x, y)
            if (d < bestDist) { bestDist = d; best = ball }
        }
        return best
    }

    private fun chosenPocket(): Pair<Float, Float>? {
        val target = targetPos ?: return null
        if (pocketIndex in pockets.indices) return pockets[pocketIndex]
        var best = pockets[0]
        var bestDist = Float.MAX_VALUE
        for (pocket in pockets) {
            val d = tableDist(target.x, target.y, pocket.first, pocket.second)
            if (d < bestDist) { bestDist = d; best = pocket }
        }
        return best
    }

    // ---- coordinate mapping: table (0..1) <-> view pixels ----
    private fun tx(x: Float): Float = tableRectPx.left + x * tableRectPx.width()
    private fun ty(y: Float): Float = tableRectPx.top + y * tableRectPx.height()
    private fun ballRadiusPx(radius: Float): Float =
        (radius * tableRectPx.width()).coerceIn(5f * density, tableRectPx.width() * 0.05f)

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (event.action == MotionEvent.ACTION_DOWN) {
            performClick()
            if (tableRectValid && tableRectPx.width() > 0) {
                val x = (event.x - tableRectPx.left) / tableRectPx.width()
                val y = (event.y - tableRectPx.top) / tableRectPx.height()
                if (x in -0.05f..1.05f && y in -0.08f..1.08f) {
                    handleTap(x.coerceIn(0f, 1f), y.coerceIn(0f, 1f))
                    return true
                }
            }
            return true // swallow taps outside the table; do not scroll away
        }
        return super.onTouchEvent(event)
    }

    override fun performClick(): Boolean = super.performClick()

    private fun handleTap(x: Float, y: Float) {
        // Finger-sized tolerances, measured in table-height units:
        // ~46dp vertically, and at least ~1.6 ball diameters.
        val tapTol = maxOf(46f * density / tableRectPx.height(), 0.16f)
        // Pocket first: a tap near a pocket chooses that pocket.
        var bestPocket = -1
        var bestPocketDist = tapTol
        for ((index, pocket) in pockets.withIndex()) {
            val d = tableDist(pocket.first, pocket.second, x, y)
            if (d < bestPocketDist) { bestPocketDist = d; bestPocket = index }
        }
        if (bestPocket >= 0 && targetPos != null) {
            pocketIndex = bestPocket
            onSelectionChanged?.invoke()
            invalidate()
            return
        }
        val tapped = nearestBall(x, y, tapTol)
        when {
            tapped == null -> {
                // Empty space: clear the target (and the pocket choice).
                targetPos = null
                pocketIndex = -1
            }
            cuePos == null -> {
                cuePos = PointF(tapped.centerX, tapped.centerY)
                cueRadius = tapped.radius
            }
            targetPos == null && tableDist(tapped.centerX, tapped.centerY, cuePos!!.x, cuePos!!.y) < 0.02f -> {
                // Tapped the cue ball again: un-pick it.
                cuePos = null
                targetPos = null
                pocketIndex = -1
            }
            targetPos != null && tableDist(tapped.centerX, tapped.centerY, targetPos!!.x, targetPos!!.y) < 0.02f -> {
                targetPos = null
                pocketIndex = -1
            }
            else -> {
                targetPos = PointF(tapped.centerX, tapped.centerY)
                targetRadius = tapped.radius
                pocketIndex = -1
            }
        }
        onSelectionChanged?.invoke()
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (width == 0 || height == 0) return
        // Letterbox the table: keep its real aspect ratio inside the view.
        val pad = 8f * density
        val availW = width - pad * 2
        val availH = height - pad * 2
        if (availW <= 0 || availH <= 0) return
        val drawW = min(availW, availH * tableAspect)
        val drawH = drawW / tableAspect
        val left = (width - drawW) / 2f
        val top = (height - drawH) / 2f
        tableRectPx.set(left, top, left + drawW, top + drawH)
        tableRectValid = true

        // Rails (thick brown frame) then the playing surface.
        railPaint.strokeWidth = 9f * density
        canvas.drawRect(
            tableRectPx.left - 4f * density, tableRectPx.top - 4f * density,
            tableRectPx.right + 4f * density, tableRectPx.bottom + 4f * density,
            railPaint
        )
        canvas.drawRect(tableRectPx, tablePaint)

        // Pockets: big black holes with a white ring — clearly visible.
        val pocketR = (drawW * 0.030f).coerceIn(10f * density, drawW * 0.045f)
        val pocket = chosenPocket()
        for ((index, p) in pockets.withIndex()) {
            val px = tx(p.first)
            val py = ty(p.second)
            canvas.drawCircle(px, py, pocketR, pocketPaint)
            canvas.drawCircle(px, py, pocketR, pocketRingPaint)
            if (pocket != null && pockets[index] == pocket && targetPos != null) {
                canvas.drawCircle(px, py, pocketR + 5f * density, chosenPocketPaint)
            }
        }

        // Aiming lines, drawn under the balls.
        drawAimLines(canvas)

        for (ball in balls) {
            val cx = tx(ball.centerX)
            val cy = ty(ball.centerY)
            val r = ballRadiusPx(ball.radius)
            ballPaint.color = Color.rgb(ball.avgRed, ball.avgGreen, ball.avgBlue)
            canvas.drawCircle(cx, cy, r, ballPaint)
            val isCue = cuePos != null &&
                tableDist(ball.centerX, ball.centerY, cuePos!!.x, cuePos!!.y) < 0.02f
            val isTarget = targetPos != null &&
                tableDist(ball.centerX, ball.centerY, targetPos!!.x, targetPos!!.y) < 0.02f
            canvas.drawCircle(
                cx, cy, r,
                when {
                    isCue -> cueRingPaint
                    isTarget -> targetRingPaint
                    ball.isWhite -> cueRingPaint
                    else -> ringPaint
                }
            )
        }

        // Labels for the picked balls.
        cuePos?.let {
            canvas.drawText("البيضاء", tx(it.x) + 10f * density, ty(it.y) - 8f * density, labelPaint)
        }
        targetPos?.let {
            canvas.drawText("الهدف", tx(it.x) + 10f * density, ty(it.y) - 8f * density, labelPaint)
        }

        if (!tableFound) {
            canvas.drawText(
                "الطاولة غير ظاهرة — كبّر اللعبة حتى تملأ الطاولة الشاشة",
                width / 2f, height / 2f, hintPaint
            )
        }
    }

    private fun drawAimLines(canvas: Canvas) {
        val cue = cuePos ?: return
        val target = targetPos ?: return
        if (tableDist(cue.x, cue.y, target.x, target.y) < 0.02f) return
        val pocket = chosenPocket() ?: return

        // Work in view pixels so the geometry stays true.
        val cueX = tx(cue.x); val cueY = ty(cue.y)
        val targetX = tx(target.x); val targetY = ty(target.y)
        val pocketX = tx(pocket.first); val pocketY = ty(pocket.second)
        val cueR = ballRadiusPx(cueRadius)
        val targetR = ballRadiusPx(targetRadius)

        // Direction from the target ball to the pocket.
        var ux = pocketX - targetX
        var uy = pocketY - targetY
        val targetDist = hypot(ux, uy)
        if (targetDist < 1f) return
        ux /= targetDist; uy /= targetDist

        // Ghost-ball position: where the cue ball's centre must be at contact.
        val ghostX = targetX - ux * (cueR + targetR)
        val ghostY = targetY - uy * (cueR + targetR)

        // 1. Aim line: cue ball -> ghost-ball position.
        canvas.drawLine(cueX, cueY, ghostX, ghostY, aimPaint)
        canvas.drawCircle(ghostX, ghostY, cueR, ghostPaint)

        // 2. Target line: target ball -> pocket.
        canvas.drawLine(targetX, targetY, pocketX, pocketY, targetLinePaint)

        // 3. Deflection: from the ghost position, roughly perpendicular
        // to the target's path, on the side the cue ball came from.
        var dx = cueX - ghostX
        var dy = cueY - ghostY
        val cueDist = hypot(dx, dy)
        if (cueDist > 1f) {
            dx /= cueDist; dy /= cueDist
            val px1 = -uy; val py1 = ux
            val dot1 = px1 * dx + py1 * dy
            val px = if (dot1 >= 0) px1 else -px1
            val py = if (dot1 >= 0) py1 else -py1
            val len = tableRectPx.width() * 0.20f
            canvas.drawLine(ghostX, ghostY, ghostX + px * len, ghostY + py * len, deflectPaint)
        }
    }
}
