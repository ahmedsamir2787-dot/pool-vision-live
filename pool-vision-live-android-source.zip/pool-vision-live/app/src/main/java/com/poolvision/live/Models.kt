package com.poolvision.live

/** One approximately detected ball, in relative 0..1 coordinates. */
data class DetectedBall(
    val centerX: Float,
    val centerY: Float,
    val radius: Float,
    val isWhite: Boolean,
    val avgRed: Int,
    val avgGreen: Int,
    val avgBlue: Int
)

data class AnalysisResult(
    val balls: List<DetectedBall>,
    val frameWidth: Int,
    val frameHeight: Int,
    val timestampMs: Long
)

/** Shared, in-process channel between the capture service and the UI. */
object AnalysisBus {
    @Volatile
    var listener: ((AnalysisResult) -> Unit)? = null

    @Volatile
    var running: Boolean = false
}
