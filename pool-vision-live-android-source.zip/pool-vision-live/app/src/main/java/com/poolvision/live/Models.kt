package com.poolvision.live

/**
 * One approximately detected ball, in TABLE-relative coordinates:
 * centerX / centerY are 0..1 inside the detected table rectangle
 * (0,0 = top-left corner of the playing surface), and radius is
 * relative to the table width. Table-relative coordinates are what
 * fix the old "balls clustered in one line" bug: previously balls
 * were reported in full-screen coordinates, so the small table area
 * (and the game's UI icon rows) were squeezed into one corner/line
 * of the drawing.
 */
data class DetectedBall(
    val centerX: Float,
    val centerY: Float,
    val radius: Float,
    val isWhite: Boolean,
    val avgRed: Int,
    val avgGreen: Int,
    val avgBlue: Int
)

/** The table rectangle found in a captured frame, in frame-relative 0..1 coordinates. */
data class TableRect(
    val left: Float,
    val top: Float,
    val right: Float,
    val bottom: Float,
    /** Pixel aspect ratio (width / height) of the table in the frame. */
    val aspect: Float
)

data class AnalysisResult(
    val balls: List<DetectedBall>,
    val frameWidth: Int,
    val frameHeight: Int,
    val timestampMs: Long,
    /** Null when no table could be found in this frame. */
    val table: TableRect? = null
)

/** Shared, in-process channel between the capture service and the UI. */
object AnalysisBus {
    @Volatile
    var listener: ((AnalysisResult) -> Unit)? = null

    @Volatile
    var running: Boolean = false
}
