package com.poolvision.live

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import kotlin.math.hypot

/**
 * Draws the latest detected balls over a table outline, plus — when a cue
 * ball and a target ball are picked — the aiming lines:
 *  cue ball -> ghost-ball position, target ball -> pocket, and the cue
 *  ball's deflection (rebound) direction after contact.
 *
 * Picking (tap on the table):
 *  - first tap on a ball marks it as the cue ball;
 *  - the next tap on another ball marks the target;
 *  - tapping near a pocket chooses that pocket instead of the nearest one;
 *  - tapping empty space clears the target (and the pocket choice).
 * If the detector finds the white ball on its own, it is picked as the
 * cue ball automatically. This manual fallback matters because the
 * colour-based white detection is approximate and can miss the cue ball.
 */
class DetectionView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private var balls: List<DetectedBall> = emptyList()
    private var cueBall: DetectedBall? = null
    private var targetBall: DetectedBall? = null
    private var pocketIndex: Int = -1 // -1 = nearest pocket to the target, automatic

    /** Called whenever the user changes the cue / target / pocket pick. */
    var onSelectionChanged: (() -> Unit)? = null

    // Six pockets: corners + middle of each long side (relative 0..1).
    private val pockets = listOf(
        0.03f to 0.03f, 0.5f to 0.02f, 0.97f to 0.03f,
        0.03f to 0.97f, 0.5f to 0.98f, 0.97f to 0.97f
    )
    private val pocketNames = listOf(
        "العلوي الأيسر", "العلوي الأوسط", "العلوي الأيمن",
        "السفلي الأيسر", "السفلي الأوسط", "السفلي الأيمن"
    )

    private val tablePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(27, 94, 52); style = Paint.Style.FILL
    }
    private val railPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(101, 67, 33); style = Paint.Style.STROKE; strokeWidth = 14f
    }
    private val ballPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; style = Paint.Style.STROKE; strokeWidth = 3f
    }
    private val whiteRingPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.YELLOW; style = Paint.Style.STROKE; strokeWidth = 5f
    }
    private val pocketPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.BLACK; style = Paint.Style.FILL
    }
    private val pocketRingPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; style = Paint.Style.STROKE; strokeWidth = 3f
    }
    private val chosenPocketPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.YELLOW; style = Paint.Style.STROKE; strokeWidth = 6f
    }
    private val aimPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; style = Paint.Style.STROKE; strokeWidth = 7f
    }
    private val targetLinePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(76, 175, 80); style = Paint.Style.STROKE; strokeWidth = 7f
    }
    private val deflectPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.YELLOW; style = Paint.Style.STROKE; strokeWidth = 5f
        pathEffect = DashPathEffect(floatArrayOf(20f, 16f), 0f)
    }
    private val ghostPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; style = Paint.Style.STROKE; strokeWidth = 4f
    }
    private val labelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; textSize = 36f
        setShadowLayer(5f, 0f, 2f, Color.BLACK)
    }

    fun submit(result: AnalysisResult) {
        balls = result.balls
        // Keep the picks glued to the nearest ball as frames refresh, so the
        // lines stay live instead of flickering away on a missed frame.
        cueBall = rematch(cueBall)
        targetBall = rematch(targetBall)
        if (cueBall == null) {
            cueBall = balls.firstOrNull { it.isWhite }
        }
        post { invalidate() }
    }

    fun clear() {
        balls = emptyList()
        cueBall = null
        targetBall = null
        pocketIndex = -1
        post { invalidate() }
    }

    /** One-line Arabic summary of the current pick, for the result text. */
    fun selectionSummary(): String {
        val cue = cueBall
        val target = targetBall
        return when {
            cue == null ->
                "الخطوط: اضغط على الكرة البيضاء أولاً، ثم على الكرة الهدف."
            target == null ->
                "البيضاء محددة ✓ — اضغط على الكرة الهدف لعرض الخطوط."
            else -> {
                val pocket = chosenPocket()
                val name = pocket?.let { pocketNames[pockets.indexOf(it)] } ?: "الأقرب"
                "الخطوط ظاهرة ✓ — الجيب: $name — اضغط على جيب آخر لتغييره، أو على مكان فاضي لمسح الهدف."
            }
        }
    }

    private fun rematch(previous: DetectedBall?): DetectedBall? {
        if (previous == null) return null
        return nearestBall(previous.centerX, previous.centerY, 0.08f)
    }

    private fun nearestBall(x: Float, y: Float, maxDist: Float): DetectedBall? {
        var best: DetectedBall? = null
        var bestDist = maxDist
        for (ball in balls) {
            val d = hypot(ball.centerX - x, ball.centerY - y)
            if (d < bestDist) { bestDist = d; best = ball }
        }
        return best
    }

    private fun chosenPocket(): Pair<Float, Float>? {
        val target = targetBall ?: return null
        if (pocketIndex in pockets.indices) return pockets[pocketIndex]
        var best = pockets[0]
        var bestDist = Float.MAX_VALUE
        for (pocket in pockets) {
            val d = hypot(target.centerX - pocket.first, target.centerY - pocket.second)
            if (d < bestDist) { bestDist = d; best = pocket }
        }
        return best
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (event.action == MotionEvent.ACTION_DOWN) {
            performClick()
            handleTap(event.x / width, event.y / height)
            return true
        }
        return super.onTouchEvent(event)
    }

    override fun performClick(): Boolean = super.performClick()

    private fun handleTap(x: Float, y: Float) {
        // Pocket first: a tap near a pocket chooses that pocket.
        var bestPocket = -1
        var bestPocketDist = 0.10f
        for ((index, pocket) in pockets.withIndex()) {
            val d = hypot(pocket.first - x, pocket.second - y)
            if (d < bestPocketDist) { bestPocketDist = d; bestPocket = index }
        }
        if (bestPocket >= 0 && targetBall != null) {
            pocketIndex = bestPocket
            onSelectionChanged?.invoke()
            invalidate()
            return
        }
        val tapped = nearestBall(x, y, 0.09f)
        when {
            tapped == null -> {
                // Empty space: clear the target (and the pocket choice).
                targetBall = null
                pocketIndex = -1
            }
            cueBall == null -> cueBall = tapped
            tapped == cueBall -> {
                cueBall = null
                targetBall = null
                pocketIndex = -1
            }
            targetBall == null || tapped != targetBall -> {
                targetBall = tapped
                pocketIndex = -1
            }
            else -> targetBall = null
        }
        onSelectionChanged?.invoke()
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (width == 0 || height == 0) return
        val w = width.toFloat()
        val h = height.toFloat()
        canvas.drawRect(0f, 0f, w, h, tablePaint)
        canvas.drawRect(7f, 7f, w - 7f, h - 7f, railPaint)

        // Pockets.
        val pocket = chosenPocket()
        for ((index, p) in pockets.withIndex()) {
            val px = p.first * w
            val py = p.second * h
            canvas.drawCircle(px, py, 16f, pocketPaint)
            canvas.drawCircle(px, py, 16f, pocketRingPaint)
            if (pocket != null && pockets[index] == pocket && targetBall != null) {
                canvas.drawCircle(px, py, 22f, chosenPocketPaint)
            }
        }

        // Aiming lines, drawn under the balls.
        drawAimLines(canvas, w, h)

        for (ball in balls) {
            val cx = ball.centerX * w
            val cy = ball.centerY * h
            val r = (ball.radius * w).coerceIn(8f, 60f)
            ballPaint.color = Color.rgb(ball.avgRed, ball.avgGreen, ball.avgBlue)
            canvas.drawCircle(cx, cy, r, ballPaint)
            val ring = when (ball) {
                cueBall -> whiteRingPaint
                targetBall -> chosenPocketPaint
                else -> if (ball.isWhite) whiteRingPaint else ringPaint
            }
            canvas.drawCircle(cx, cy, r, ring)
        }

        // Labels for the picked balls.
        cueBall?.let { canvas.drawText("البيضاء", it.centerX * w + 14f, it.centerY * h - 14f, labelPaint) }
        targetBall?.let { canvas.drawText("الهدف", it.centerX * w + 14f, it.centerY * h - 14f, labelPaint) }
    }

    private fun drawAimLines(canvas: Canvas, w: Float, h: Float) {
        val cue = cueBall ?: return
        val target = targetBall ?: return
        if (cue == target) return
        val pocket = chosenPocket() ?: return

        // Work in pixels so the geometry stays true on a non-square view.
        val cueX = cue.centerX * w
        val cueY = cue.centerY * h
        val targetX = target.centerX * w
        val targetY = target.centerY * h
        val pocketX = pocket.first * w
        val pocketY = pocket.second * h
        val cueR = (cue.radius * w).coerceIn(8f, 60f)
        val targetR = (target.radius * w).coerceIn(8f, 60f)

        // Direction from the target ball to the pocket.
        var ux = pocketX - targetX
        var uy = pocketY - targetY
        val targetDist = hypot(ux, uy)
        if (targetDist < 1f) return
        ux /= targetDist
        uy /= targetDist

        // Ghost-ball position: where the cue ball's centre must be at contact.
        val ghostX = targetX - ux * (cueR + targetR)
        val ghostY = targetY - uy * (cueR + targetR)

        // 1. Aim line: cue ball -> ghost-ball position.
        canvas.drawLine(cueX, cueY, ghostX, ghostY, aimPaint)
        canvas.drawCircle(ghostX, ghostY, cueR, ghostPaint)

        // 2. Target line: target ball -> pocket.
        canvas.drawLine(targetX, targetY, pocketX, pocketY, targetLinePaint)

        // 3. Deflection: from the ghost position, roughly perpendicular to the
        // target's path, on the side the cue ball came from (dashed).
        var dx = cueX - ghostX
        var dy = cueY - ghostY
        val cueDist = hypot(dx, dy)
        if (cueDist > 1f) {
            dx /= cueDist
            dy /= cueDist
            // Two perpendicular options; take the one closer to the incoming direction.
            val px1 = -uy
            val py1 = ux
            val dot1 = px1 * dx + py1 * dy
            val px = if (dot1 >= 0) px1 else -px1
            val py = if (dot1 >= 0) py1 else -py1
            val len = w * 0.22f
            canvas.drawLine(ghostX, ghostY, ghostX + px * len, ghostY + py * len, deflectPaint)
        }
    }
}
