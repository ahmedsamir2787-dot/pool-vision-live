package com.poolvision.live

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.Spinner
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var statusText: TextView
    private lateinit var resultText: TextView
    private lateinit var detectionView: DetectionView
    private lateinit var startButton: Button
    private lateinit var stopButton: Button
    private lateinit var resolutionSpinner: Spinner
    private lateinit var intervalSpinner: Spinner

    // width px choices, low -> high (lower = less battery)
    private val widths = listOf(540, 720, 1080)
    private val intervals = listOf(250L, 500L, 1000L)
    private var lastResult: AnalysisResult? = null

    private val captureLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            val intent = Intent(this, ScreenCaptureService::class.java).apply {
                putExtra(ScreenCaptureService.EXTRA_RESULT_CODE, result.resultCode)
                putExtra(ScreenCaptureService.EXTRA_DATA, result.data)
                putExtra(
                    ScreenCaptureService.EXTRA_WIDTH,
                    widths[resolutionSpinner.selectedItemPosition]
                )
                putExtra(
                    ScreenCaptureService.EXTRA_INTERVAL,
                    intervals[intervalSpinner.selectedItemPosition]
                )
            }
            ContextCompat.startForegroundService(this, intent)
            setRunningUi(true)
        } else {
            statusText.text = "الحالة: تم إلغاء إذن مشاركة الشاشة"
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        statusText = findViewById(R.id.statusText)
        resultText = findViewById(R.id.resultText)
        detectionView = findViewById(R.id.detectionView)
        startButton = findViewById(R.id.startButton)
        stopButton = findViewById(R.id.stopButton)
        resolutionSpinner = findViewById(R.id.resolutionSpinner)
        intervalSpinner = findViewById(R.id.intervalSpinner)

        resolutionSpinner.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item,
            listOf("منخفضة — 540px (توفير بطارية)", "متوسطة — 720px", "عالية — 1080px")
        )
        resolutionSpinner.setSelection(1)
        intervalSpinner.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item,
            listOf("سريع — كل 250ms", "متوازن — كل 500ms", "موفّر — كل 1000ms")
        )
        intervalSpinner.setSelection(1)

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 7)
        }

        AnalysisBus.listener = { result ->
            runOnUiThread {
                lastResult = result
                detectionView.submit(result)
                renderResult()
            }
        }
        // Tapping the table picks the cue / target / pocket: refresh the text.
        detectionView.onSelectionChanged = {
            runOnUiThread { renderResult() }
        }

        startButton.setOnClickListener {
            val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE)
                as MediaProjectionManager
            // Official system consent dialog — the user must approve.
            captureLauncher.launch(mpm.createScreenCaptureIntent())
        }
        stopButton.setOnClickListener {
            startService(Intent(this, ScreenCaptureService::class.java).apply {
                action = ScreenCaptureService.ACTION_STOP
            })
            detectionView.clear()
            setRunningUi(false)
        }
    }

    private fun renderResult() {
        val result = lastResult ?: return
        val white = result.balls.count { it.isWhite }
        val lines = result.balls.take(16).joinToString("\n") { b ->
            val kind = if (b.isWhite) "بيضاء" else "ملونة"
            "• كرة $kind عند (${(b.centerX * 100).toInt()}٪، ${(b.centerY * 100).toInt()}٪)"
        }
        resultText.text =
            "${detectionView.selectionSummary()}\nعدد الكرات: ${result.balls.size} — منها بيضاء: $white\n$lines"
    }

    private fun setRunningUi(running: Boolean) {
        startButton.isEnabled = !running
        stopButton.isEnabled = running
        statusText.text = if (running) "الحالة: التحليل يعمل الآن" else "الحالة: متوقف"
        if (!running) resultText.text = "عدد الكرات: 0"
    }

    override fun onDestroy() {
        if (AnalysisBus.listener != null) AnalysisBus.listener = null
        super.onDestroy()
    }
}
